"""Gambar model Live2D dengan Python murni -- tanpa JS, tanpa browser, tanpa WebView2.

Ini jawaban yang bisa dijalankan untuk pertanyaan "bisa nggak gerakin vtuber-nya
pakai Python?". Bisa, dan berkas ini buktinya: model .moc3 digambar langsung ke
konteks OpenGL yang kita buat sendiri lewat **live2d-py**, pembungkus Cubism Native
SDK 5-r.5 (Python C Extension). Yang dipakai di sini Cubism Core 06.00.0001.

    # sekali saja: lingkungan terpisah, karena live2d-py butuh Python >= 3.11
    # sementara proyek ini memakai 3.10 untuk torch/rvc.
    python -m venv var/venv-live2d
    var\\venv-live2d\\Scripts\\python.exe -m pip install live2d-py glfw PyOpenGL numpy

    var\\venv-live2d\\Scripts\\python.exe scripts/live2d_python.py            # jendela
    var\\venv-live2d\\Scripts\\python.exe scripts/live2d_python.py --png      # tangkap PNG

Terukur 29 Sep di mesin ini (i5-1135G7 / Iris Xe, OpenGL 4.6): 358 parameter,
9 ekspresi, 1 grup gerak berisi 4 motion, dan 431.605 piksel tidak transparan dari
kanvas 900x1200. PNG-nya di `var/live2d-python.png`.

**Kenapa ini penting, dan apa harganya.** Jalur sekarang (WebView2 + Pixi) memang
sudah digerakkan Python -- JS-nya cuma menggambar. Yang mahal dari jalur itu adalah
*rumahnya*: pywebview tidak membuat jendela beralfa sungguhan, jadi `jendela.py`
menambal dengan color key dan meninggalkan rim tipis di tepi antialias. Jendela
OpenGL sendiri tidak punya masalah itu: alfa asli, dari sumbernya.

Yang **belum** ikut pindah dan itu pekerjaan tersendiri: seluruh `web/*.js` yang
menerjemahkan tag jadi wajah/pose/gerak, mesin keadaan, dan irama render. Kontrak
`.env`-nya sudah ada dan API live2d-py menutup hampir semuanya (`SetExpression`,
`AddExpression`, `LoadExtraExpression`, `StartMotion`, `LoadExtraMotion`,
`SetParameterValue`, `SetScale`, `SetOffset`, `live2d.utils.lipsync`). Menyalinnya
tetap berarti dua sumber kebenaran selama jalur web masih hidup -- persis yang
dihindari `web/tampak.js` selama ini. Jadi berkas ini adalah **bukti kelayakan**,
bukan pengganti.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import glfw
import numpy as np
import OpenGL

# PyOpenGL memeriksa glGetError() di SETIAP panggilan dan melempar kalau ada sisa
# galat. Cubism Native SDK memakai FBO/shader sendiri, jadi antrean galatnya kadang
# terisi oleh operasi yang sah -- dan pemeriksaan itu melaporkannya di panggilan
# berikutnya (glClearColor), yang menyesatkan. Dimatikan, sama seperti contoh resmi
# live2d-py.
OpenGL.ERROR_CHECKING = False
OpenGL.ERROR_LOGGING = False

import OpenGL.GL as GL  # noqa: E402  -- harus sesudah setelan di atas
from PIL import Image  # noqa: E402

AKAR = Path(__file__).resolve().parent.parent
MODEL_BAWAAN = AKAR / "public" / "models" / "silverwolf" / "silverwolf.model3.json"
PNG_BAWAAN = AKAR / "var" / "live2d-python.png"


def gambar(model, jendela, lebar: int, tinggi: int, frame: int) -> np.ndarray:
    """Jalankan `frame` kali update+draw, pulangkan piksel frame terakhir (RGBA)."""
    import live2d.v3 as live2d

    gambar_terakhir = None
    for i in range(frame):
        model.Update()
        live2d.clearBuffer(0.0, 0.0, 0.0, 0.0)

        # State GL yang diminta Cubism. Tanpa ini Draw() berjalan tanpa menggambar
        # satu piksel pun -- dan itu terjadi tanpa galat, jadi mudah disalahartikan
        # sebagai "modelnya kosong".
        GL.glPushAttrib(
            GL.GL_CURRENT_BIT | GL.GL_ENABLE_BIT | GL.GL_POLYGON_BIT | GL.GL_COLOR_BUFFER_BIT
        )
        GL.glUseProgram(0)
        GL.glDisable(GL.GL_DEPTH_TEST)
        GL.glDisable(GL.GL_CULL_FACE)
        GL.glEnable(GL.GL_BLEND)
        GL.glBlendFuncSeparate(
            GL.GL_ONE, GL.GL_ONE_MINUS_SRC_ALPHA, GL.GL_ONE, GL.GL_ONE_MINUS_SRC_ALPHA
        )
        model.Draw()
        GL.glPopAttrib()

        if i == frame - 1:
            # Dibaca dari back buffer SEBELUM swap: sesudah swap isinya tak tentu.
            mentah = GL.glReadPixels(0, 0, lebar, tinggi, GL.GL_RGBA, GL.GL_UNSIGNED_BYTE)
            gambar_terakhir = np.frombuffer(mentah, dtype=np.uint8).reshape(tinggi, lebar, 4)
        glfw.swap_buffers(jendela)
    return gambar_terakhir


def utama() -> int:
    urai = argparse.ArgumentParser(description="render Live2D dengan Python murni")
    urai.add_argument("--model", default=str(MODEL_BAWAAN))
    urai.add_argument("--lebar", type=int, default=900)
    urai.add_argument("--tinggi", type=int, default=1200)
    urai.add_argument("--frame", type=int, default=30, help="frame sebelum dinilai stabil")
    urai.add_argument("--ekspresi", default="", help="mis. sebal; kosong = wajah bawaan")
    urai.add_argument("--png", nargs="?", const=str(PNG_BAWAAN), default=None,
                      help="jendela disembunyikan, tangkap ke PNG (boleh beri jalur)")
    urai.add_argument("--detik", type=float, default=0.0,
                      help="tanpa --png: berapa lama jendela dibiarkan terbuka (0 = sampai ditutup)")
    arg = urai.parse_args()

    jalur_model = Path(arg.model)
    if not jalur_model.is_file():
        print(f"model tidak ada: {jalur_model}", file=sys.stderr)
        return 2

    import live2d.v3 as live2d
    from live2d.v3 import LAppModel

    live2d.init()
    if not glfw.init():
        print("glfw.init gagal", file=sys.stderr)
        return 3

    if arg.png:
        glfw.window_hint(glfw.VISIBLE, glfw.FALSE)
    jendela = glfw.create_window(arg.lebar, arg.tinggi, "Silver Wolf — Python", None, None)
    if not jendela:
        print("create_window gagal", file=sys.stderr)
        glfw.terminate()
        return 4
    glfw.make_context_current(jendela)
    glfw.swap_interval(1 if not arg.png else 0)
    live2d.glInit()
    GL.glViewport(0, 0, arg.lebar, arg.tinggi)

    print("OpenGL :", GL.glGetString(GL.GL_VERSION).decode())
    print("vendor :", GL.glGetString(GL.GL_VENDOR).decode())

    model = LAppModel()
    model.LoadModelJson(str(jalur_model))
    model.CreateRenderer()  # WAJIB: tanpa ini Draw() tidak menghasilkan piksel apa pun
    model.Resize(arg.lebar, arg.tinggi)

    print("parameter  :", model.GetParameterCount())
    print("kanvas     :", model.GetCanvasSize())
    print("ekspresi   :", model.GetExpressionIds())
    print("grup gerak :", {k: len(v) for k, v in model.GetMotions().items()})

    if arg.ekspresi:
        if arg.ekspresi in model.GetExpressionIds():
            model.SetExpression(arg.ekspresi, 0)
            print(f"ekspresi dipakai: {arg.ekspresi}")
        else:
            print(f"ekspresi '{arg.ekspresi}' tidak ada di model", file=sys.stderr)
            return 5

    if arg.png:
        piksel = gambar(model, jendela, arg.lebar, arg.tinggi, arg.frame)
        gambar_akhir = np.flipud(piksel)  # origin OpenGL di kiri-bawah
        tujuan = Path(arg.png)
        tujuan.parent.mkdir(parents=True, exist_ok=True)
        Image.fromarray(gambar_akhir, "RGBA").save(tujuan)
        alfa = gambar_akhir[:, :, 3]
        print(f"piksel tidak transparan: {(alfa > 0).sum()} dari {alfa.size}")
        print(f"PNG: {tujuan}")
    else:
        batas = arg.detik if arg.detik > 0 else float("inf")
        import time

        mulai = time.time()
        while not glfw.window_should_close(jendela):
            model.Update()
            live2d.clearBuffer(0.0, 0.0, 0.0, 0.0)
            GL.glPushAttrib(
                GL.GL_CURRENT_BIT | GL.GL_ENABLE_BIT | GL.GL_POLYGON_BIT | GL.GL_COLOR_BUFFER_BIT
            )
            GL.glUseProgram(0)
            GL.glDisable(GL.GL_DEPTH_TEST)
            GL.glDisable(GL.GL_CULL_FACE)
            GL.glEnable(GL.GL_BLEND)
            GL.glBlendFuncSeparate(
                GL.GL_ONE, GL.GL_ONE_MINUS_SRC_ALPHA, GL.GL_ONE, GL.GL_ONE_MINUS_SRC_ALPHA
            )
            model.Draw()
            GL.glPopAttrib()
            glfw.swap_buffers(jendela)
            glfw.poll_events()
            if time.time() - mulai > batas:
                break

    glfw.terminate()
    live2d.dispose()
    return 0


if __name__ == "__main__":
    sys.exit(utama())
