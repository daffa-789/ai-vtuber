"""Ukur nada dasar (F0) tiap WAV hasil adu_suara supaya pemilihan suara punya angka.

Dua estimator dijalankan berdampingan dan **keduanya dilaporkan**:

* autokorelasi -- cepat, akurat pada sinyal bersih;
* cepstrum nyata -- memisahkan periodisitas (F0) dari selubung spektral (formant),
  jadi ia tidak salah kunci pada sinyal berformant kuat atau bersuara kasar.

Alasan dua-duanya: 29 Sep autokorelasi melaporkan 345 Hz untuk satu render yang
cepstrum-nya bilang 226 Hz, sementara di render lain keduanya sepakat dalam 1 Hz.
Melaporkan satu angka saja berarti menyembunyikan persis kasus yang paling perlu
dilihat. Kalau kolom putusan bilang TIDAK SEPAKAT, **jangan pakai angka itu** --
dengar berkasnya.

    .venv\\Scripts\\python.exe scripts/ukur_f0.py %TEMP%\\adu-suara
"""

from __future__ import annotations

import sys
import wave
from pathlib import Path

import numpy as np

F0_MIN, F0_MAKS = 60.0, 400.0
PANJANG, HOP = 0.040, 0.020
AMBANG_BERSUARA = 0.02
SEBAR_MAKS = 15.0  # Hz; di atas ini kedua estimator dianggap tidak sepakat


def baca_wav(jalur: Path) -> tuple[np.ndarray, int]:
    with wave.open(str(jalur), "rb") as w:
        sr = w.getframerate()
        kanal = w.getnchannels()
        lebar = w.getsampwidth()
        mentah = w.readframes(w.getnframes())
    if lebar != 2:
        raise ValueError(f"{jalur.name}: sampel {lebar*8}-bit, bukan PCM16")
    x = np.frombuffer(mentah, dtype="<i2").astype(np.float64)
    if kanal > 1:
        x = x.reshape(-1, kanal).mean(axis=1)
    return x / 32768.0, sr


def _bingkai_bersuara(x: np.ndarray, sr: int):
    """Frame 40 ms yang energinya di atas ambang, hop 20 ms."""
    n = int(PANJANG * sr)
    h = int(HOP * sr)
    for mulai in range(0, len(x) - n, h):
        b = x[mulai : mulai + n]
        if np.sqrt(np.mean(b**2)) < AMBANG_BERSUARA:
            continue
        yield b - b.mean()


def f0_autokorelasi(x: np.ndarray, sr: int) -> np.ndarray:
    n = int(PANJANG * sr)
    lag_min, lag_maks = int(sr / F0_MAKS), int(sr / F0_MIN)
    hasil = []
    for bingkai in _bingkai_bersuara(x, sr):
        akor = np.correlate(bingkai, bingkai, mode="full")[n - 1 :]
        if akor[0] <= 0:
            continue
        akor = akor / akor[0]
        puncak = akor[lag_min:lag_maks]
        if not len(puncak):
            continue
        i = int(np.argmax(puncak))
        if puncak[i] < 0.3:  # bukan periodik -> bukan suara
            continue
        lag = lag_min + i
        # interpolasi parabola supaya resolusinya tidak terbatas 1 sampel
        if 0 < lag < len(akor) - 1:
            a, b, c = akor[lag - 1], akor[lag], akor[lag + 1]
            denom = 2 * (2 * b - a - c)
            if denom:
                lag = lag + (c - a) / denom
        if lag > 0:
            hasil.append(sr / lag)
    return np.array(hasil)


def f0_cepstrum(x: np.ndarray, sr: int) -> np.ndarray:
    """Cepstrum nyata: puncak di quefrency = periode dasar."""
    n = 4096
    hop = int(HOP * sr)
    jendela = np.hanning(n)
    q_min, q_maks = int(sr / F0_MAKS), int(sr / F0_MIN)
    hasil = []
    for mulai in range(0, len(x) - n, hop):
        bingkai = x[mulai : mulai + n]
        if np.sqrt(np.mean(bingkai**2)) < AMBANG_BERSUARA:
            continue
        spek = np.abs(np.fft.rfft(bingkai * jendela))
        ceps = np.fft.irfft(np.log(spek + 1e-12))
        if q_maks >= len(ceps):
            continue
        puncak = ceps[q_min:q_maks]
        if not len(puncak):
            continue
        q = q_min + int(np.argmax(puncak))
        if q > 0:
            hasil.append(sr / q)
    return np.array(hasil)


def ukur(jalur: Path) -> tuple[float, float, int] | None:
    """(autokorelasi, cepstrum, jumlah frame). None kalau tidak ada frame bersuara."""
    x, sr = baca_wav(jalur)
    a = f0_autokorelasi(x, sr)
    c = f0_cepstrum(x, sr)
    if not len(a) or not len(c):
        return None
    return float(np.median(a)), float(np.median(c)), int(min(len(a), len(c)))


def main() -> int:
    folder = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
    berkas = sorted(folder.glob("*.wav"))
    if not berkas:
        print(f"tidak ada .wav di {folder}", file=sys.stderr)
        return 2

    print(f"{'berkas':<20}{'autokorelasi':>14}{'cepstrum':>12}{'frame':>7}  putusan")
    for jalur in berkas:
        # "1-rvct+12i0.6.wav" -> varian "rvct+12i0.6"
        label = jalur.stem.split("-", 1)[1] if "-" in jalur.stem else jalur.stem
        try:
            hasil = ukur(jalur)
        except Exception as err:
            print(f"{label:<20}  GALAT {err}")
            continue
        if hasil is None:
            print(f"{label:<20}{'—':>14}{'—':>12}{0:>7}  tidak ada frame bersuara")
            continue
        a, c, frame = hasil
        if abs(a - c) > SEBAR_MAKS:
            putusan = f"TIDAK SEPAKAT ({abs(a - c):.0f} Hz) -- dengar berkasnya"
        else:
            putusan = f"{float(np.median([a, c])):.1f} Hz"
        print(f"{label:<20}{a:>11.1f} Hz{c:>9.1f} Hz{frame:>7}  {putusan}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
