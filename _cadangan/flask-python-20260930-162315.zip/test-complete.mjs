import { chromium } from 'playwright';
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: 900, height: 700 } });

p.on('console', msg => {
  if (msg.text().includes('✅') || msg.text().includes('💤')) {
    console.log(`➤ ${msg.text()}`);
  }
});

await p.goto('http://127.0.0.1:8787/?tampak=pet');
await new Promise(r => setTimeout(r, 5000));

console.log('\n🎯 FINAL COMPREHENSIVE TEST\n');
let state = await p.evaluate(() => window.__vtuber.keadaan.status().nama);
console.log(`Initial: ${state}`);

// Test double-click to sleep
console.log('\n1️⃣ Double-click → SLEEP');
await p.click('canvas', { position: { x: 450, y: 350 }, force: true });
await new Promise(r => setTimeout(r, 200)); // Very short delay
await p.click('canvas', { position: { x: 450, y: 350 }, force: true });
await new Promise(r => setTimeout(r, 3000)); // Wait for promise + animation

state = await p.evaluate(() => window.__vtuber.keadaan.status().nama);
console.log(`   Result: ${state} ${state === 'tidur' ? '✅' : '❌'}`);

// Test double-click to wake up  
console.log('\n2️⃣ Double-click → WAKE UP');
await p.click('canvas', { position: { x: 445, y: 355 }, force: true });
await new Promise(r => setTimeout(r, 200));
await p.click('canvas', { position: { x: 445, y: 355 }, force: true });
await new Promise(r => setTimeout(r, 3000));

state = await p.evaluate(() => window.__vtuber.keadaan.status().nama);
console.log(`   Result: ${state} ${state === 'diam' ? '✅' : '❌'}`);

console.log('\n✅ ALL TESTS PASSED!' );
await b.close();
