"""Engine pengubah WARNA suara: RVC v2 dengan checkpoint Furina.

Bukan TTS. RVC butuh audio sumber -- ia tidak menyusun teks jadi suara. Di sini
sumbernya keluaran Piper (lafal + irama bahasa Indonesia), dan RVC hanya
mengganti timbrenya. Karena itu engine ini boleh mati (VTUBER_RVC=tidak) tanpa
membisukan apa pun.

Satu-satunya pemegang RVCInference di proyek ini, dan hanya boleh disentuh dari
thread pekerja jalur_suara: muat model 190-370 MB ke RAM dan bukan sesuatu yang
aman dipakai dua thread sekaligus.

Catatan DLL yang terukur di mesin ini (2026-09-26): `import faiss` sebelum
`import torch` membuat torch gagal dengan WinError 1114 pada c10.dll. Jalur
rvc_python.infer kebetulan sudah aman (modules.py memuat torch di baris 8,
pipeline.py baru memuat faiss di baris 11), tapi itu bergantung pada urutan
berkas pihak ketiga -- makanya `import torch` ditulis eksplisit lebih dulu.
"""

from __future__ import annotations

import os
import threading
import uuid
from pathlib import Path

import konfig
from konfig import AKAR
from wav import AMBANG_DENGAR, baca_header, puncak, sudah_wav

NAMA = "rvc"

# Konversi RVC terukur 4-15 dtk per kalimat di mesin ini. Di bawah angka ini,
# menolak lebih murah daripada memulai kerja yang pasti tidak akan ditunggu.
WAKTU_MINIMUM = 3.0

_rvc = None
_lock = threading.Lock()
_galat_terakhir = ""


class RvcTidakHidup(Exception):
    """RVC dimatikan atau asetnya belum ada -- bukan kegagalan, jangan diadu."""


class RvcGagal(Exception):
    """Percobaan konversi benar-benar gagal."""


def folder_model() -> Path:
    p = Path(konfig.RVC_FOLDER)
    return p if p.is_absolute() else AKAR / p


def _pilih_indeks(folder: Path) -> Path | None:
    """*.index yang dipakai: `VTUBER_RVC_INDEKS` kalau diisi, kalau tidak yang pertama.

    Kunci RVC_INDEKS sudah lama ada di konfig.py tapi TIDAK PERNAH dibaca siapa
    pun -- mengisinya di .env tidak mengubah apa pun, dan itu persis kelas bug
    "resep diabaikan tanpa pesan" yang sudah beberapa kali terjadi di proyek ini.
    Sekarang ia berlaku: berguna kalau satu folder checkpoint punya lebih dari
    satu index hasil latih.
    """
    if konfig.RVC_INDEKS:
        p = Path(konfig.RVC_INDEKS)
        if not p.is_absolute():
            p = folder / p
        if p.is_file():
            return p
    idx = sorted(folder.glob("*.index"))
    return idx[0] if idx else None


def berkas_rncunan() -> tuple[Path | None, Path | None, str]:
    """(pth, index, nama) untuk model terpilih, mengikuti cara rvc_python memindai.

    rvc_python._load_available_models() men-scan models_dir/*/ dan mengambil
    *.pth + *.index pertama, jadi bentuk folder inilah kontraknya -- nama model
    di .env adalah nama SUBFOLDER, bukan nama berkas.
    """
    folder = folder_model() / konfig.RVC_MODEL
    if not folder.is_dir():
        return (None, None, konfig.RVC_MODEL)
    pth = sorted(folder.glob("*.pth"))
    return (pth[0] if pth else None, _pilih_indeks(folder), konfig.RVC_MODEL)


def siap() -> bool:
    """Murah: cek berkas + modul bisa diimpor. TIDAK menyentuh konstruktor."""
    pth, _, _ = berkas_rncunan()
    return pth is not None and _rvc_terpasang()


def hidup() -> bool:
    return konfig.RVC_HIDUP and siap()


def _rvc_terpasang() -> bool:
    try:
        import importlib.util

        return importlib.util.find_spec("rvc_python") is not None
    except Exception:
        return False


def izinkan_global_torch() -> None:
    """Daftar putih kelas yang ada di dalam checkpoint HuBERT/RMVPE.

    PyTorch >= 2.6 membalik bawaan `torch.load` menjadi weights_only=True.
    checkpoint fairseq menyimpan objek `fairseq.data.dictionary.Dictionary` dan
    `argparse.Namespace`, jadi muatnya ditolak -- bukan karena berkasnya rusak,
    tapi karena sandbox-nya sekarang ketat. rvc_python memanggil torch.load tanpa
    menyebut weights_only, jadi kita TIDAK menutup sandbox itu (opsi yang lebih
    gampang tapi berarti berkas .pth pihak ketiga bisa mengeksekusi kode apa pun
    di meja Master); kita hanya membuka dua pintu yang memang dibutuhkan.

    Kalau kelak muncul "Unsupported global: GLOBAL x.y.Z", itu bukan kegagalan
    yang harus disweep di bawah karpet: tambah nama kelasnya ke sini supaya
    daftar yang dipercaya tetap terbaca dan bisa diaudit.
    """
    import torch

    calon: list = []
    try:
        from fairseq.data.dictionary import Dictionary

        calon.append(Dictionary)
    except Exception:
        pass
    import argparse

    calon.append(argparse.Namespace)
    try:
        torch.serialization.add_safe_globals(calon)
    except Exception:
        pass  # torch lama tanpa add_safe_globals -> bawaannya sudah weights_only=False


def muat() -> None:
    """Idempoten. Hanya boleh dipanggil dari thread pekerja jalur_suara."""
    global _rvc, _galat_terakhir
    with _lock:
        if _rvc is not None:
            return
        if not konfig.RVC_HIDUP:
            raise RvcTidakHidup("VTUBER_RVC=tidak")
        pth, idx, nama = berkas_rncunan()
        if pth is None:
            raise RvcTidakHidup(
                f"checkpoint tidak ada di {folder_model() / nama} "
                "(salin checkpoint .pth ke folder itu)"
            )
        if not _rvc_terpasang():
            raise RvcTidakHidup("rvc_python belum diinstal (pip install -r requirements.txt)")

        import torch  # noqa: F401  -- WAJIB sebelum rvc_python, lihat docstring modul
        try:
            torch.set_num_threads(min(4, os.cpu_count() or 4))
        except Exception:
            pass

        izinkan_global_torch()
        import warnings
        warnings.filterwarnings("ignore", category=FutureWarning)
        from rvc_python.infer import RVCInference

        try:
            rvc = RVCInference(
                models_dir=str(folder_model()),
                device="cpu:0",  # tidak ada NVIDIA di mesin ini; jangan ditulis cuda
            )
            rvc.load_model(nama, version=konfig.RVC_VERSI, index_path="")
            rvc.set_params(**param_aktif())
        except Exception as err:
            _galat_terakhir = f"muat RVC gagal: {err}"
            raise RvcGagal(_galat_terakhir) from err
        _rvc = rvc
        # rvc_python memilih *.index PERTAMA di folder (infer.py:47). Kalau
        # VTUBER_RVC_INDEKS menunjuk berkas lain, pasang yang itu -- dan hanya
        # kalau memang berbeda, supaya barisnya tidak jadi no-op seperti dulu.
        terpasang = str((_rvc.models.get(nama) or {}).get("index") or "")
        if idx is not None and str(idx) != terpasang:
            _rvc.models[nama]["index"] = str(idx)


def indeks_dipakai() -> str:
    """Ringkas: index mana yang akan benar-benar dipakai pada setelan sekarang.

    Dipakai banner dan alasan_tidak_tersedia() supaya "index mati" tidak lagi
    jadi keadaan senyap -- inilah satu-satunya tuas yang membuat hasil RVC
    terdengar seperti pemilik checkpoint, bukan cuma seperti RVC generik.
    """
    _, idx, _ = berkas_rncunan()
    if konfig.RVC_INDEKS_LAJU <= 0:
        return "index tidak dipakai (VTUBER_RVC_INDEKS_LAJU=0)"
    if idx is None:
        return "index diminta tapi tidak ada *.index di folder model"
    return f"index {idx.name} @ {konfig.RVC_INDEKS_LAJU:g}"


def param_aktif() -> dict:
    """Peta kunci kita -> nama parameter rvc_python (namanya tidak bisa ditebak)."""
    return {
        "f0method": konfig.RVC_F0,
        "f0up_key": konfig.RVC_TRANSPOSE,
        "index_rate": konfig.RVC_INDEKS_LAJU,
        "filter_radius": konfig.RVC_PENCUCIAN,
        "resample_sr": konfig.RVC_RESAMPLE,
        "rms_mix_rate": konfig.RVC_CAMPUR_RMS,
        "protect": konfig.RVC_PROTEKSI,
    }


def patokan_cache() -> str:
    """Kunci cache: ganti checkpoint ATAU parameter apa pun -> miss sendiri.

    Dibangun dari `param_aktif()` yang SAMA dengan yang dikirim ke RVC, bukan
    dari daftar kunci yang ditulis ulang di sini. Dulu daftarnya ditulis ulang
    dan empat kunci terlewat -- filter_radius, resample_sr, rms_mix_rate,
    protect -- jadi mengubahnya di .env memulangkan audio LAMA dari cache tanpa
    satu pesan pun. Meng-iterasi param_aktif() membuat kelas bug itu tidak bisa
    terulang walau nanti ada parameter baru.
    """
    pth, idx, nama = berkas_rncunan()

    def tanda(p: Path | None) -> str:
        if p is None:
            return "tidak-ada"
        st = p.stat()
        return f"{st.st_size}:{int(st.st_mtime)}"

    p = param_aktif()
    bagian = ["rvc", nama, konfig.RVC_VERSI]
    bagian += [f"{kunci}={p[kunci]}" for kunci in sorted(p)]
    bagian.append(tanda(pth))
    bagian.append(tanda(idx) if p["index_rate"] else "tanpa-index")
    return "|".join(bagian)


def ubah(wav_masuk: bytes, label: str = "", sisa: float = 0.0) -> bytes:
    """WAV masuk -> WAV keluar dengan timbre model. Lewat berkas, karena itu
    satu-satunya antarmuka yang disediakan rvc_python (infer_file/infer_dir).

    `sisa` (detik anggaran yang masih ada) dipakai sebagai pagar masuk, bukan
    pembatal di tengah jalan -- infer_file tidak bisa dihentikan. Kalau waktunya
    sudah tidak cukup untuk mengerjakan apa pun, lebih baik menolak sekarang dan
    membiarkan rantai pindah engine daripada memegang pekerja 7 detik untuk hasil
    yang tidak akan ditunggu siapa pun.
    """
    if not konfig.RVC_HIDUP:
        raise RvcTidakHidup("VTUBER_RVC=tidak")
    if sisa and sisa < WAKTU_MINIMUM:
        raise RvcGagal(
            f"anggaran tinggal {sisa:.1f} dtk, di bawah {WAKTU_MINIMUM:.0f} dtk yang "
            "dibutuhkan satu konversi -- lewati resep ini"
        )
    muat()

    # Nama berkas temp WAJIB unik per permintaan. Dua alasan yang sama-sama sunyi:
    # cache_harvest_f0 di rvc_python di-lru_cache berdasarkan PATH berkas (nama
    # sama = F0 kalimat sebelumnya dipulangkan), dan input_audio_path2wav global.
    folder_tmp = AKAR / "var" / "tmp-suara"
    folder_tmp.mkdir(parents=True, exist_ok=True)
    alias = uuid.uuid4().hex
    masuk = folder_tmp / f"{alias}_masuk.wav"
    keluar = folder_tmp / f"{alias}_keluar.wav"

    try:
        masuk.write_bytes(wav_masuk)
        _rvc.set_params(**param_aktif())
        try:
            import torch
            with torch.inference_mode():
                _rvc.infer_file(str(masuk), str(keluar))
        except Exception as err:
            # vc_single MENELAN semua exception dan mengembalikan string traceback,
            # lalu infer_file meledak di dalam wavfile.write. Galat yang sampai ke
            # sini biasanya tidak menjelaskan apa pun.
            #
            # `sebab asli` dijalankan di sini berarti konversi KEDUA yang utuh
            # (4-15 dtk lagi) sambil memegang satu-satunya pekerja -- tepat saat
            # rantai sedang gagal. Jadi hanya atas permintaan, lewat diagnostik().
            sebab = (
                _telusuri(str(masuk))
                if konfig.TTS_METERIK
                else "sebab asli hanya dipakai saat VTUBER_TTS_METERIK=ya "
                     "atau lewat fungsi diagnosa di bawah"
            )
            raise RvcGagal(f"{err} | {sebab}") from err

        if not keluar.is_file():
            raise RvcGagal(f"RVC tidak menulis berkas keluaran ({label})")
        byte = keluar.read_bytes()
        if not sudah_wav(byte) or len(byte) <= 44:
            raise RvcGagal(f"keluaran RVC bukan WAV utuh ({len(byte)} byte, {label})")
        _, _, detik = baca_header(byte)
        if detik <= 0.02:
            raise RvcGagal(f"keluaran RVC terlalu pendek ({detik:.3f} dtk, {label})")
        # Durasi BUKAN bukti ada suaranya. Keluaran 40 kHz penuh nol lolos
        # baca_header, lolos decodeAudioData browser, dan menghasilkan rahang yang
        # diam seribu bahasa -- lalu masuk cache dan membisukan kalimat itu selamanya.
        if puncak(byte) <= AMBANG_DENGAR:
            raise RvcGagal(f"keluaran RVC hening ({detik:.2f} dtk, {label})")
        return byte
    finally:
        for p in (masuk, keluar):
            try:
                os.remove(p)
            except OSError:
                pass


def _telusuri(jalur_masuk: str) -> str:
    """Panggil vc_single langsung supaya traceback yang ditelan paket kelihatan."""
    try:
        nama = _rvc.current_model
        hasil = _rvc.vc.vc_single(
            sid=0,
            input_audio_path=jalur_masuk,
            f0_up_key=konfig.RVC_TRANSPOSE,
            f0_method=konfig.RVC_F0,
            file_index=_rvc.models[nama].get("index") or "",
            file_index2="",
            index_rate=konfig.RVC_INDEKS_LAJU,
            filter_radius=konfig.RVC_PENCUCIAN,
            resample_sr=konfig.RVC_RESAMPLE,
            rms_mix_rate=konfig.RVC_CAMPUR_RMS,
            protect=konfig.RVC_PROTEKSI,
            f0_file="",
        )
        if isinstance(hasil, tuple) and isinstance(hasil[0], str):
            return hasil[0].strip()
        return "vc_single tampak berhasil; kegagalan ada di penulisan berkas"
    except Exception as err:
        return str(err)


def diagnostik(wav_masuk: bytes) -> str:
    """Diagnostik: kembalikan laporan keadaan model, bukan byte audio."""
    if not hidup():
        return "RVC mati atau asetnya belum ada"
    muat()
    folder_tmp = AKAR / "var" / "tmp-suara"
    folder_tmp.mkdir(parents=True, exist_ok=True)
    masuk = folder_tmp / f"diagnostik_{uuid.uuid4().hex}.wav"
    try:
        masuk.write_bytes(wav_masuk)
        pesan = _telusuri(str(masuk))
        sr = getattr(getattr(_rvc, "vc", None), "tgt_sr", "?")
        return f"tgt_sr={sr} | f0={konfig.RVC_F0} | transpose={konfig.RVC_TRANSPOSE}\n{pesan}"
    finally:
        try:
            os.remove(masuk)
        except OSError:
            pass


def alasan_tidak_tersedia() -> str:
    if not konfig.RVC_HIDUP:
        return "VTUBER_RVC=tidak"
    pth, _, nama = berkas_rncunan()
    if pth is None:
        return f"checkpoint {nama} belum ditaruh di {folder_model()}"
    if not _rvc_terpasang():
        return "rvc_python belum diinstal"
    if _galat_terakhir:
        return _galat_terakhir
    # "rvc siap" saja dulu menutupi satu keadaan yang justru menentukan warna
    # suaranya: index yang tidak dipakai. Sekarang keadaannya ikut disebut.
    return f"rvc siap · {indeks_dipakai()}"
