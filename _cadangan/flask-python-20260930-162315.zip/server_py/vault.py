"""Transport catatan karakter: folder `silver_wolf_memory/` di dalam proyek ini.

Dulu tulisannya lewat Local REST API vault Obsidian (http://127.0.0.1:27123). Itu
mati diam-diam: Obsidian tidak selalu jalan, jadi setiap percakapan kehilangan
memorinya -- terukur 28 Sep, `memori tidak terbaca: <urlopen error timed out>` lalu
`memori gagal ditulis: Obsidian sedang offline (cooldown 30s)`. Companion yang tidak
ingat adalah bugsnya fitur utamanya, jadi memorinya pindah ke berkas biasa di sini:
tidak ada port, tidak ada token, tidak ada yang bisa offline.

Berkas-nya tetap Markdown ber-frontmatter dengan tautan [[wiki]], jadi folder ini
kalau nanti mau dibuka di Obsidian masih terbaca -- hanya bukan dia yang menyimpan
kebenarannya.

FOLDER INI BERISI FAKTA NYATA TENTANG MASTER (kota, nama tokonya). `.gitignore`
menolak seluruh isinya; jangan pernah melepas baris itu -- repo ini publik.
"""

from __future__ import annotations

import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

from konfig import AKAR

PANGKAL = AKAR / "silver_wolf_memory"
if not PANGKAL.is_dir() and (AKAR / "silver_wolf memory").is_dir():
    PANGKAL = AKAR / "silver_wolf memory"
elif not PANGKAL.is_dir() and (AKAR / "memori-waifu").is_dir():
    PANGKAL = AKAR / "memori-waifu"

# Links wajib ditulis: tanpa field `links`, file hasil auto-save jadi node yatim di
# graph view. `_Index` SENGAJA tidak ada di sini -- satu tautan itu menyeret
# seluruh folder karakter ke graph Qoder Memory. Lihat _PETUNJUK.md.
TAUTAN_DASAR = ["silverwolf-persona"]


def tersedia() -> bool:
    return PANGKAL.is_dir()


def alasan_tidak_tersedia() -> str:
    return f"folder {PANGKAL} tidak ada"


def _tanggal() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def _baca(nama: str) -> tuple[int, str]:
    """Meniru bentuk transport lama: (status, isi). 404 = berkas belum ada."""
    path = PANGKAL / nama
    if not path.is_file():
        return 404, ""
    try:
        return 200, path.read_text(encoding="utf-8")
    except OSError as err:
        print(f"  ! memori tidak terbaca: {err}", file=sys.stderr, flush=True)
        return 500, ""


def _tulis(nama: str, isi: str) -> None:
    path = PANGKAL / nama
    path.parent.mkdir(parents=True, exist_ok=True)
    # Tulis-then-replace: proses yang mati di tengah tulis tidak boleh meninggalkan
    # Fakta.md separuh, karena itu yang dibaca ulang tiap balasan berikutnya.
    sementara = path.with_suffix(path.suffix + ".tmp")
    sementara.write_text(isi, encoding="utf-8")
    os.replace(sementara, path)


def _kerangka(nama: str, judul: str, isi: str, tautan: list[str] | None = None) -> str:
    links = list(dict.fromkeys([*TAUTAN_DASAR, *(tautan or [])]))
    baris = [
        "---",
        "type: memory",
        "kind: karakter",
        "wilayah: waifu",
        f'name: "{nama}"',
        f'description: "{judul}"',
        'project: "Desktop AI VTUBER"',
        f'updated: "{_tanggal()}"',
        "tags:",
        '  - "memory/karakter"',
        '  - "wilayah/waifu"',
        '  - "project/Desktop AI VTUBER"',
        "links:",
        *[f'  - "[[{l}]]"' for l in links],
        "---",
        "",
        f"# {judul}",
        "",
        isi.strip(),
        "",
    ]
    return "\n".join(baris)


# ── Fakta: daftar yang dia ingat tentang user.
def simpan_fakta(fakta: list[str]) -> None:
    panduan = (
        "Setiap baris di bawah masuk ke prompt sebagai sesuatu yang **dia ingat benar**.\n"
        "Aturannya: hanya yang pernah Master tulis sendiri di percakapan, atau yang\n"
        "terukur dari mesin ini. Dugaan yang belum pasti pindah ke [[Dugaan]] dan tidak boleh\n"
        "ditulis sebagai kenyataan. Selera kanonik dan preferensi lengkap dicatat di [[Preferences]],\n"
        "suasana hati di [[Mood]], dan rekaman harian di [[Riwayat]].\n\n"
    )
    isi = panduan + ("\n".join(f"- {f}" for f in fakta) if fakta else "_Belum ada fakta tersimpan._")
    _tulis(
        "Fakta.md",
        _kerangka(
            "fakta-silverwolf",
            "Fakta yang Silver Wolf ingat tentang Master",
            isi,
            ["Mood", "Quotes", "Riwayat", "Dugaan", "Preferences", "Scenario_Library", "System_Documentation", "_PETUNJUK"],
        ),
    )


def baca_fakta() -> list[str]:
    status, teks = _baca("Fakta.md")
    if status != 200:
        return []
    hasil = []
    for baris in teks.split("\n"):
        if baris.startswith("- "):
            isi = baris[2:].strip()
            if isi and not isi.startswith("_"):
                hasil.append(isi)
    return hasil


# ── Mood: state emosional, dibaca ulang tiap percakapan.
def simpan_mood(mood: dict) -> None:
    isi = "\n".join(
        x
        for x in [
            f"Valensi: {mood['valensi']:.2f} (-1 berat .. +1 senang)",
            f"Energi: {mood['energi']:.2f}",
            f"Afinitas: {mood['afinitas']:.2f} (0 jauh .. 1 dekat)",
            f"Pertukaran tercatat: {mood['pertukaran']}",
            "Terakhir diperbarui: "
            + datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
            f"Alasan: {mood['alasan']}" if mood.get("alasan") else "",
        ]
        if x
    )
    _tulis(
        "Mood.md",
        _kerangka(
            "mood-silverwolf",
            "Suasana hati Silver Wolf saat ini",
            isi,
            ["Fakta", "Quotes", "Riwayat", "Preferences", "Dugaan", "Scenario_Library", "System_Documentation", "_PETUNJUK"],
        ),
    )


def baca_mood() -> dict | None:
    status, teks = _baca("Mood.md")
    if status != 200:
        return None

    def ambil(kunci: str):
        cocok = re.search(rf"{kunci}: (-?[\d.]+)", teks)
        return float(cocok.group(1)) if cocok else float("nan")

    valensi, energi, afinitas = ambil("Valensi"), ambil("Energi"), ambil("Afinitas")
    if any(v != v for v in (valensi, energi, afinitas)):  # NaN = label tidak cocok
        return None
    tertukar = re.search(r"Pertukaran tercatat: (\d+)", teks)
    return {
        "valensi": valensi,
        "energi": energi,
        "afinitas": afinitas,
        "pertukaran": int(tertukar.group(1)) if tertukar else 0,
    }


# ── Riwayat harian: satu catatan per tanggal, ditambah bukan ditimpa.
def catat_hari(baris: str) -> None:
    nama = f"Riwayat/{_tanggal()}.md"
    status, lama = _baca(nama)
    badan = [l for l in lama.split("\n") if l.startswith("- ")] if status == 200 else []
    badan.append(f"- {baris}")
    _tulis(
        nama,
        _kerangka(
            f"riwayat-{_tanggal()}",
            f"Riwayat percakapan {_tanggal()}",
            "\n".join(badan),
            ["Fakta", "Mood", "Quotes", "Riwayat", "Preferences", "Dugaan"],
        ),
    )
