@echo off
REM Build Silver Wolf Desktop Pet as .exe using PyInstaller

cd /d "%~dp0"
echo ========================================
echo Building Silver Wolf Desktop Pet EXE
echo ========================================

REM Check if dependencies are installed
echo [1/3] Checking dependencies...
python -m pip list | findstr /C:"PyQt5" >nul 2>&1
if errorlevel 1 (
    echo ERROR: PyQt5 not found. Installing...
    python -m pip install PyQt5 numpy pillow python-dotenv
)

REM Remove old build artifacts
echo [2/3] Cleaning previous builds...
rmdir /s /q build 2>nul
del silverwolf-pet.spec 2>nul

REM Create PyInstaller spec file
echo Creating spec file...
python -c "
from PyInstaller.utils.hooks import collect_data_files, collect_submodules
imports = collect_submodules('PyQt5')
datas = []
for m in imports:
    try:
        data = collect_data_files(m)
        datas.extend(data)
    except: pass
with open('silverwolf-pet.spec', 'w', encoding='utf-8') as f:
    f.write('''# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('assets/*', 'assets'),
    ],
    hiddenimports=[
        'PyQt5',
        'PyQt5.QtWidgets',
        'PyQt5.QtGui',
        'PyQt5.QtCore',
        'numpy',
        'pillow',
        'python_dotenv',
    ] + %s,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='SilverWolf_Pet',
    appdata=None,
    console=True,  # Set False for no console window
    debug=False,
    bootstrap_interval=1,
    icon='icons\\icon.ico',  # Optional: add icon path
    target_name='SilverWolf_Pet.exe',
)
''' % str(list(set([i.split('.')[0] for i in imports if not i.startswith('__')])))[:2000])
print('Spec file created.')
"

REM Build executable
echo [3/3] Building executable...
pyinstaller silverwolf-pet.spec --noconfirm

REM Show results
echo.
echo Build completed!
echo Output files in dist folder:
dir dist\SilverWolf_Pet.exe
echo.
echo To run the application:
echo   dist\SilverWolf_Pet.exe
echo.
pause
