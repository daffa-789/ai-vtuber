#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Silver Wolf Desktop Pet - Main Entry Point

Native Windows application that runs as a desktop pet overlay
with full Live2D rendering, voice synthesis, and desktop integration.
"""

import os
import sys
from pathlib import Path

# Add project root to path for imports
ROOT = Path(__file__).parent.resolve()
sys.path.insert(0, str(ROOT))

try:
    from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel
    from PyQt5.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, QRectF
    from PyQt5.QtGui import QPainter, QColor, QFont, QIcon
    print("✓ PyQt5 modules loaded")
except ImportError as err:
    print(f"✗ Import error: {err}")
    print("\nPyQt5 not installed. Install with:")
    print("  .venv\\Scripts\\python.exe -m pip install PyQt5 numpy pillow")
    sys.exit(1)


class TestWindow(QWidget):
    """Basic PyQt5 window for testing Live2D integration."""
    
    def __init__(self):
        super().__init__()
        
        # Window configuration
        self.setWindowTitle("Silver Wolf - Desktop Pet Test")
        self.setFixedSize(400, 600)  # Initial size, will be fullscreen
        
        # Make it frameless and transparent for desktop pet behavior
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        # Center on primary monitor initially
        screen = QApplication.primaryScreen().geometry()
        self.move(
            (screen.width() - 400) // 2,
            (screen.height() - 600) // 2
        )
        
        # Setup UI elements
        self.setup_ui()
        
        # Animation timers
        self.floating_timer = QTimer(self)
        self.floating_timer.timeout.connect(self.float_animation)
        self.floating_timer.start(16)  # ~60 FPS for smooth animation
        
        print("Test window initialized")
    
    def setup_ui(self):
        """Setup basic UI for testing."""
        self.label = QLabel("Silver Wolf\nDesktop Pet\nReady!", self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setStyleSheet("""
            QLabel {
                color: white;
                font-size: 24px;
                font-family: Arial;
                background: transparent;
            }
        """)
        
        # Vertical layout with stretch
        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addStretch()
        self.setLayout(layout)
    
    def float_animation(self):
        """Simple floating animation effect."""
        y_offset = int(5 * abs((self.y() % 100) / 50 - 1))
        if y_offset != 0:
            self.moveTo(self.x(), self.y() + y_offset)
    
    def paintEvent(self, event):
        """Custom painting for debug info."""
        painter = QPainter(self)
        painter.setPen(QColor("white"))
        painter.drawText(10, 30, 
            "Double-click to toggle sleep\n"
            "Right-click for menu\n"
            "Drag to move"
        )


def main():
    """Application entry point."""
    print("=" * 50)
    print("Silver Wolf Desktop Pet - PyQt5 Test")
    print("=" * 50)
    
    # Create application instance
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)  # Don't quit when window closed
    
    # Create and show test window
    window = TestWindow()
    window.show()
    
    print("\n[INFO] Window is now visible.")
    print("[INFO] Double-click to test interactions")
    print("[INFO] Press Ctrl+C to exit\n")
    
    # Run event loop
    try:
        sys.exit(app.exec_())
    except KeyboardInterrupt:
        print("\nShutting down...")
        return 0
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
