// Gerbang tag ekspresi: mana yang boleh dipanggil chat, dan bagaimana bentuknya
// di layar. Nama wajah, pose, dan gerakan TIDAK ditulis di sini -- ketiganya
// datang dari .env (VITE_WAJAH_*, VITE_POSE_*, VITE_GERAK_*), lihat setelan.js.
import { setelan } from './setelan.js';

/** Tag yang mengganti raut wajah; satu wajah aktif pada satu waktu. */
export const NAMA_WAJAH = new Set(setelan.wajah.map((w) => w.nama));

/** Tag `[prop:nama]`; pose/aksesoris ini ditumpuk di atas wajah, bukan menggantikannya. */
export const NAMA_POSE = new Set(setelan.pose.map((p) => p.nama));

/** Tag `[gerak:nama]`; sekali jalan, namanya dari VITE_GERAK_ yang sama. */
export const NAMA_GERAK = new Set(setelan.gerakan.map((g) => g.nama));

export const EKSPRESI_DASAR = setelan.ekspresiDasar;

/**
 * Mengupas tag `[...]` dari aliran teks tanpa menampilkannya ke layar.
 * Sisa potongan tag di akhir chunk ditahan sampai chunk berikutnya, supaya
 * penonton tidak pernah melihat `[se` lewat di gelembung chat.
 */
export function kupasTag(picu) {
  // Body wajib diawali huruf: tanpa itu `array[3]` dan `buf[0]` di jawaban soal
  // kode ikut termakan sebagai tag (bug lama, terukur 28 Sep).
  // 1..26 karakter: cukup untuk kanal kedua, `[prop:tangan-1=mati]`, tapi masih
  // pendek untuk tidak menelan kurung siku biasa.
  // Backtick/kutip di SEBELUM dan SESUDAH kurung ikut dimakan: model lokal 3B
  // sering menulis `[kaget]` padahal persona melarangnya, dan kalau hanya kurung
  // sikunya yang dibuang, dua karakter itu tertinggal di gelembung chat.
  const TAG = /[`'"]?\[([a-zA-Z][^\n[]{0,25})\][`'"]?/g;
  let simpan = '';

  return {
    tulis(chunk) {
      const teks = simpan + chunk;
      let keluaran = '';
      let batas = 0;
      TAG.lastIndex = 0;

      let m = TAG.exec(teks);
      while (m) {
        keluaran += teks.slice(batas, m.index);
        picu(m[1].trim().toLowerCase());
        batas = TAG.lastIndex;
        m = TAG.exec(teks);
      }

      const ekor = teks.slice(batas);
      const buka = ekor.lastIndexOf('[');
      if (buka === -1) {
        keluaran += ekor;
        simpan = '';
      } else {
        keluaran += ekor.slice(0, buka);
        simpan = ekor.slice(buka);
      }
      return keluaran;
    },

    // Tag yang tidak pernah tertutup berarti model tidak menaati format:
    // tampilkan apa adanya daripada menghilangkannya diam-diam.
    tutup() {
      const sisa = simpan;
      simpan = '';
      return sisa;
    },
  };
}
