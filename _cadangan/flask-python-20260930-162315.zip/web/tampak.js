/**
 * Mode tampilan: browser (panel lengkap) atau pet (melayang di desktop).
 *
 * Ditentukan dari URL: pywebview membuka `/?tampak=pet`, browser biasa membuka `/`.
 * Satu halaman, dua wujud -- sengaja, supaya kontrak DOM yang dipakai chat.js dan
 * main.js (#log, #isi, #btn-mic, #stage, ...) tidak bercabang jadi dua sumber
 * kebenaran yang bisa berbeda diam-diam.
 *
 * Panggil pasangTampil() SEBELUM PIXI.Application dibuat: ia menulis
 * `html[data-tampak]`, dan CSS mode pet mengubah kanvas mengisi jendela. Kalau
 * dipanggil setelahnya, kanvas dibuat dengan ukuran lama lalu tidak pernah ikut.
 */

export function modeTampil() {
  try {
    return new URLSearchParams(location.search).get('tampak') === 'pet' ? 'pet' : 'browser';
  } catch {
    return 'browser';
  }
}

/** @returns {'pet'|'browser'} mode yang aktif */
export function pasangTampil() {
  const mode = modeTampil();
  if (mode !== 'pet') {
    // Mode browser tidak punya kotak obrolan yang bisa disembunyikan; hotkey
    // global tetap memanggil nama ini, jadi ia harus ADA dan menjawab dengan jujur
    // -- bukan melempar, karena lemparannya muncul sebagai galat di log Python
    // yang sama sekali tidak ada hubungannya dengan penyebabnya.
    window.__vtuberPanel = () => false;
    return mode;
  }

  const html = document.documentElement;
  html.dataset.tampak = 'pet';

  const panelTerbuka = () => document.body.classList.contains('panel-terbuka');
  const ubahPanel = (buka) => document.body.classList.toggle('panel-terbuka', buka);

  const fokusIsi = () => {
    const isi = document.getElementById('isi');
    if (isi) setTimeout(() => isi.focus(), 30);
  };

  /**
   * Satu-satunya pintu untuk membuka/menutup kotak obrolan, dipakai bersama oleh
   * klik kanan (di bawah) dan hotkey global dari Python (lewat evaluate_js).
   * Sengaja satu pintu: dua jalur yang menulis keadaan yang sama adalah cara
   * tercepat membuat keduanya berbeda diam-diam.
   * Tanpa argumen = balikkan keadaan sekarang.
   */
  window.__vtuberPanel = (buka) => {
    ubahPanel(buka === undefined ? !panelTerbuka() : !!buka);
    if (panelTerbuka()) fokusIsi();
    return panelTerbuka();
  };

  // Menu kanan ditangani oleh Windows (ContextMenuStrip) di proses Python -- tidak perlu
  // handler JavaScript. Kita tetap pasangkan hotkey global agar Esc menutup panel.

  // Esc menutup; klik di luar panel (di atas tubuhnya) juga menutup, supaya pet
  // tidak tertinggal sebagai kartu yang menempel di layar.
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && panelTerbuka()) {
      e.preventDefault();
      ubahPanel(false);
    }
  });
  document.addEventListener('pointerdown', (e) => {
    if (!panelTerbuka()) return;
    const panel = document.getElementById('panel');
    if (panel && !panel.contains(e.target)) ubahPanel(false);
  });

  // Double-click untuk toggle sleep/wake mode
  let lastClickTime = 0;
  let lastClickTarget = null;
  
  document.addEventListener('mousedown', async (e) => {
    const panel = document.getElementById('panel');
    // Check if clicking on panel or UI elements (but NOT canvas)
    const isPanelElement = panel?.contains(e.target) || e.target.closest('button') || 
                           e.target.closest('input') || 
                           (e.target.parentElement?.id === 'panel' && !e.target.classList.contains('toggle-sleep'));
    
    // Allow clicks on canvas and outside panel area for double-click toggle
    if (!isPanelElement) {
      const now = Date.now();
      const sameTarget = lastClickTarget === e.target;
      
      // Debug log to verify listener is firing
      console.log('🖱️ Click detected:', { target: e.target.tagName, type: e.type });
      
      if (now - lastClickTime < 300 && sameTarget) {
        console.log('✅ Double-click detected! Toggling sleep...');
        try {
          // Wait for async toggle to complete
          await window.__vtuber.keadaan.toggleSleep();
          const finalState = window.__vtuber.keadaan.status().nama;
          console.log('💤 State after toggle:', finalState);
        } catch (err) {
          console.warn('❌ Toggle error:', err.message);
        }
        lastClickTime = 0;
        lastClickTarget = null;
      } else {
        lastClickTime = now;
        lastClickTarget = e.target;
      }
    }
  }, { passive: false });
  
  return mode;
}
